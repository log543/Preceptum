class WorksheetExporter {
    constructor() {
        this.initializeExport();
    }

    initializeExport() {
        // Add event listeners to export buttons
        document.querySelectorAll('.export-button').forEach(button => {
            button.addEventListener('click', (e) => {
                const format = e.target.closest('.export-card').dataset.format;
                this.handleExport(format);
            });
        });
    }

    async handleExport(format) {
        this.showLoading();

        try {
            switch (format) {
                case 'pdf':
                    await this.exportToPDF();
                    break;
                case 'word':
                    await this.exportToWord();
                    break;
                case 'print':
                    this.printWorksheet();
                    break;
                case 'html':
                    this.exportToHTML();
                    break;
            }
        } catch (error) {
            console.error('Export failed:', error);
            alert('Export failed. Please try again.');
        }

        this.hideLoading();
    }

    showLoading() {
        const overlay = document.createElement('div');
        overlay.className = 'loading-overlay';
        overlay.innerHTML = '<div class="loading-spinner"></div>';
        document.body.appendChild(overlay);
        // Force reflow
        overlay.offsetHeight;
        overlay.classList.add('active');
    }

    hideLoading() {
        const overlay = document.querySelector('.loading-overlay');
        if (overlay) {
            overlay.classList.remove('active');
            setTimeout(() => overlay.remove(), 300);
        }
    }

    async exportToPDF() {
        // Implement PDF export logic
        // You'll need to use a library like jsPDF or handle server-side conversion
    }

    async exportToWord() {
        // Implement Word export logic
        // You can use libraries like docx or handle server-side conversion
    }

    printWorksheet() {
        window.print();
    }

    exportToHTML() {
        const worksheetContent = document.querySelector('.worksheet-container').innerHTML;
        const html = `
            <!DOCTYPE html>
            <html>
            <head>
                <title>Math Worksheet</title>
                <style>
                    /* Add your worksheet styles here */
                </style>
            </head>
            <body>
                ${worksheetContent}
            </body>
            </html>
        `;

        const blob = new Blob([html], { type: 'text/html' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'math-worksheet.html';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
    }
}

// Initialize exporter
new WorksheetExporter(); 