document.addEventListener('DOMContentLoaded', function() {
    const topicsData = {
        1: [
            { title: 'Addition within 20', description: 'Basic addition with numbers up to 20' },
            { title: 'Subtraction within 20', description: 'Basic subtraction with numbers up to 20' },
            { title: 'Counting to 100', description: 'Number sequence and counting skills' },
            { title: 'Shapes', description: 'Basic 2D shapes and their properties' }
        ],
        2: [
            { title: 'Addition within 100', description: 'Two-digit addition' },
            { title: 'Subtraction within 100', description: 'Two-digit subtraction' },
            { title: 'Place Value', description: 'Understanding tens and ones' },
            { title: 'Money', description: 'Counting coins and bills' }
        ],
        // Add more grade levels and their topics...
        'university': [
            { title: 'Calculus', description: 'Limits, derivatives, and integrals' },
            { title: 'Linear Algebra', description: 'Vectors, matrices, and linear transformations' },
            { title: 'Statistics', description: 'Probability and data analysis' },
            { title: 'Abstract Algebra', description: 'Groups, rings, and fields' }
        ]
    };

    const gradeButtons = document.querySelectorAll('.grade-btn');
    const topicsGrid = document.getElementById('topicsGrid');
    const currentGradeSpan = document.querySelector('.current-grade');

    function showTopics(grade) {
        const topics = topicsData[grade] || [];
        topicsGrid.innerHTML = '';
        
        topics.forEach(topic => {
            const topicCard = document.createElement('div');
            topicCard.className = 'topic-card';
            topicCard.innerHTML = `
                <h3>${topic.title}</h3>
                <p>${topic.description}</p>
            `;
            topicCard.addEventListener('click', () => {
                window.location.href = `generator.html?topic=${encodeURIComponent(topic.title)}`;
            });
            topicsGrid.appendChild(topicCard);
        });
    }

    gradeButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Remove active class from all buttons
            gradeButtons.forEach(btn => btn.classList.remove('active'));
            // Add active class to clicked button
            button.classList.add('active');
            
            const grade = button.dataset.grade;
            currentGradeSpan.textContent = button.textContent;
            showTopics(grade);
        });
    });

    // Show initial topics
    showTopics(1);
}); 