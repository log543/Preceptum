class WorksheetGenerator {
    constructor() {
        // Wait for DOM to be ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.initialize());
        } else {
            this.initialize();
        }
    }

    initialize() {
        this.form = document.getElementById('worksheetForm');
        if (!this.form) return; // Exit if form not found

        this.previewArea = document.querySelector('.worksheet-preview');
        
        // Initialize event listeners
        this.form.addEventListener('submit', (e) => this.handleGenerate(e));
        
        // Initialize other event listeners only if elements exist
        const previewButton = document.querySelector('.preview-actions .secondary-button');
        if (previewButton) {
            previewButton.addEventListener('click', () => this.printWorksheet());
        }

        const topicSelect = document.getElementById('topic');
        if (topicSelect) {
            topicSelect.addEventListener('change', (e) => this.updateTopicOptions(e));
        }

        // Initialize topic handlers
        this.topicHandlers = {
            'Addition': this.generateAddition,
            'Subtraction': this.generateSubtraction,
            'Multiplication': this.generateMultiplication,
            'Division': this.generateDivision,
            'Fractions': this.generateFractions,
            'Mixed Numbers': this.generateMixedNumbers,
            'Decimals': this.generateDecimals
        };

        // Update button listeners
        const downloadBtn = document.getElementById('downloadPdf');
        const printBtn = document.getElementById('printWorksheet');
        
        if (downloadBtn) {
            downloadBtn.addEventListener('click', () => this.downloadPDF());
        }
        if (printBtn) {
            printBtn.addEventListener('click', () => this.printWorksheet());
        }

        // Add input validation for question count
        const questionInput = this.form.querySelector('input[type="number"]');
        if (questionInput) {
            questionInput.addEventListener('input', (e) => this.validateQuestionCount(e));
            questionInput.addEventListener('change', (e) => this.validateQuestionCount(e));
            questionInput.setAttribute('max', '20');
            
            // Add arrow key listener
            questionInput.addEventListener('keydown', (e) => {
                const currentValue = parseInt(questionInput.value);
                if (e.key === 'ArrowUp' && currentValue >= 20) {
                    e.preventDefault();
                    this.showPremiumPopup();
                }
            });
        }

        // Add popup event listeners
        document.querySelectorAll('.close-popup').forEach(button => {
            button.addEventListener('click', () => this.closePopup());
        });

        const upgradeBtn = document.getElementById('upgradeButton');
        if (upgradeBtn) {
            upgradeBtn.addEventListener('click', () => {
                window.location.href = '#pricing';
                this.closePopup();
            });
        }

        // Initialize custom options
        this.initializeCustomOptions();

        // Check for topic parameter in URL
        const urlParams = new URLSearchParams(window.location.search);
        const topicParam = urlParams.get('topic');
        if (topicParam && topicSelect) {
            // Set the topic if it exists in the select options
            const option = Array.from(topicSelect.options).find(opt => opt.text === topicParam);
            if (option) {
                topicSelect.value = option.value;
                this.updateTopicOptions({ target: topicSelect });
            }
        }
    }

    initializeCustomOptions() {
        // Time limit handling
        document.getElementById('timeLimit').addEventListener('input', (e) => {
            this.updateTimeLimit(e.target.value);
        });

        // Font size changes
        document.querySelector('select[name="fontSize"]').addEventListener('change', (e) => {
            this.updateFontSize(e.target.value);
        });

        // Layout changes
        document.querySelector('select[name="layout"]').addEventListener('change', (e) => {
            this.updateLayout(e.target.value);
        });

        // Problem format changes
        document.querySelectorAll('input[name="problemFormat"]').forEach(radio => {
            radio.addEventListener('change', (e) => {
                this.updateProblemFormat(e.target.id);
            });
        });

        // Custom title handling
        const titleCheckbox = document.getElementById('customTitle');
        const titleInput = document.getElementById('worksheetTitle');
        titleCheckbox.addEventListener('change', () => {
            titleInput.style.display = titleCheckbox.checked ? 'block' : 'none';
        });

        // Instructions handling
        const instructionsCheckbox = document.getElementById('instructions');
        const instructionsInput = document.getElementById('customInstructions');
        instructionsCheckbox.addEventListener('change', () => {
            instructionsInput.style.display = instructionsCheckbox.checked ? 'block' : 'none';
        });
    }

    updateTimeLimit(time) {
        if (time > 0) {
            // Add timer to worksheet
            this.addTimerToWorksheet(time);
        }
    }

    updateFontSize(size) {
        const preview = document.querySelector('.worksheet-preview');
        preview.style.fontSize = this.getFontSize(size);
    }

    updateLayout(layout) {
        const preview = document.querySelector('.worksheet-preview');
        preview.className = `worksheet-preview layout-${layout}`;
    }

    updateProblemFormat(format) {
        this.problemFormat = format;
        if (this.currentProblems) {
            this.displayWorksheet(this.currentProblems);
        }
    }

    getFontSize(size) {
        const sizes = {
            small: '14px',
            medium: '16px',
            large: '18px'
        };
        return sizes[size] || '16px';
    }

    validateQuestionCount(e) {
        const input = e.target;
        const value = parseInt(input.value);
        
        // Check if value exceeds 20
        if (value > 20) {
            this.showPremiumPopup();
            input.value = 20; // Reset to 20
        }
    }

    showPremiumPopup() {
        const popup = document.getElementById('premiumPopup');
        popup.classList.add('show');
        document.body.style.overflow = 'hidden';
        
        // Focus on upgrade button for accessibility
        document.getElementById('upgradeButton').focus();
    }

    closePopup() {
        const popup = document.getElementById('premiumPopup');
        popup.classList.remove('show');
        document.body.style.overflow = '';
        
        // Reset question count to 20
        const questionInput = this.form.querySelector('input[type="number"]');
        questionInput.value = 20;
        
        // Return focus to question input
        questionInput.focus();
    }

    updateTopicOptions(e) {
        const grade = document.querySelector('select[name="grade"]').value;
        const topic = e.target.value;
        const difficulty = document.querySelector('input[name="difficulty"]:checked').id;
    }

    handleGenerate(e) {
        e.preventDefault();
        const numQuestions = parseInt(this.form.querySelector('input[type="number"]').value);
        
        if (numQuestions > 20) {
            this.showPremiumPopup();
            return;
        }

        const formData = new FormData(this.form);
        const topic = document.getElementById('topic').value;
        const difficulty = document.querySelector('input[name="difficulty"]:checked').id;
        const grade = document.querySelector('select[name="grade"]').value;
        
        const problems = this.generateProblems(topic, numQuestions, difficulty, grade);
        this.displayWorksheet(problems);
    }

    generateProblems(topic, numQuestions, difficulty, grade) {
        const handler = this.topicHandlers[topic];
        if (!handler) return [];
        
        return Array.from({ length: numQuestions }, () => 
            handler.call(this, difficulty, grade)
        );
    }

    generateAddition(difficulty) {
        let num1, num2;
        switch(difficulty) {
            case 'easy':
                num1 = Math.floor(Math.random() * 10) + 1;
                num2 = Math.floor(Math.random() * 10) + 1;
                break;
            case 'medium':
                num1 = Math.floor(Math.random() * 50) + 10;
                num2 = Math.floor(Math.random() * 50) + 10;
                break;
            case 'hard':
                num1 = Math.floor(Math.random() * 100) + 50;
                num2 = Math.floor(Math.random() * 100) + 50;
                break;
        }
        return {
            problem: `${num1} + ${num2} = `,
            answer: num1 + num2
        };
    }

    generateSubtraction(difficulty) {
        let num1, num2;
        switch(difficulty) {
            case 'easy':
                num2 = Math.floor(Math.random() * 10) + 1;
                num1 = num2 + Math.floor(Math.random() * 10) + 1;
                break;
            case 'medium':
                num2 = Math.floor(Math.random() * 50) + 10;
                num1 = num2 + Math.floor(Math.random() * 50) + 10;
                break;
            case 'hard':
                num2 = Math.floor(Math.random() * 100) + 50;
                num1 = num2 + Math.floor(Math.random() * 100) + 50;
                break;
        }
        return {
            problem: `${num1} - ${num2} = `,
            answer: num1 - num2
        };
    }

    generateMultiplication(difficulty) {
        let num1, num2;
        switch(difficulty) {
            case 'easy':
                num1 = Math.floor(Math.random() * 5) + 1;
                num2 = Math.floor(Math.random() * 5) + 1;
                break;
            case 'medium':
                num1 = Math.floor(Math.random() * 10) + 5;
                num2 = Math.floor(Math.random() * 10) + 5;
                break;
            case 'hard':
                num1 = Math.floor(Math.random() * 12) + 8;
                num2 = Math.floor(Math.random() * 12) + 8;
                break;
        }
        return {
            problem: `${num1} × ${num2} = `,
            answer: num1 * num2
        };
    }

    generateDivision(difficulty) {
        let num1, num2;
        switch(difficulty) {
            case 'easy':
                num2 = Math.floor(Math.random() * 5) + 1;
                num1 = num2 * (Math.floor(Math.random() * 5) + 1);
                break;
            case 'medium':
                num2 = Math.floor(Math.random() * 10) + 5;
                num1 = num2 * (Math.floor(Math.random() * 10) + 1);
                break;
            case 'hard':
                num2 = Math.floor(Math.random() * 12) + 8;
                num1 = num2 * (Math.floor(Math.random() * 12) + 1);
                break;
        }
        return {
            problem: `${num1} ÷ ${num2} = `,
            answer: num1 / num2
        };
    }

    generateFractions(difficulty, grade) {
        let num1, num2, denom1, denom2;
        
        switch(difficulty) {
            case 'easy':
                denom1 = Math.floor(Math.random() * 5) + 2; // 2 to 6
                denom2 = Math.floor(Math.random() * 5) + 2;
                num1 = Math.floor(Math.random() * (denom1 - 1)) + 1;
                num2 = Math.floor(Math.random() * (denom2 - 1)) + 1;
                break;
            case 'medium':
                denom1 = Math.floor(Math.random() * 7) + 4; // 4 to 10
                denom2 = Math.floor(Math.random() * 7) + 4;
                num1 = Math.floor(Math.random() * (denom1 - 1)) + 1;
                num2 = Math.floor(Math.random() * (denom2 - 1)) + 1;
                break;
            case 'hard':
                denom1 = Math.floor(Math.random() * 11) + 6; // 6 to 16
                denom2 = Math.floor(Math.random() * 11) + 6;
                num1 = Math.floor(Math.random() * (denom1 - 1)) + 1;
                num2 = Math.floor(Math.random() * (denom2 - 1)) + 1;
                break;
        }

        const operation = Math.random() < 0.5 ? '+' : '-';
        const problem = `${num1}/${denom1} ${operation} ${num2}/${denom2} = `;
        
        // Calculate answer
        let answer;
        if (operation === '+') {
            answer = this.addFractions(num1, denom1, num2, denom2);
        } else {
            answer = this.subtractFractions(num1, denom1, num2, denom2);
        }
        
        return { problem, answer };
    }

    generateMixedNumbers(difficulty, grade) {
        let whole1, whole2, num1, num2, denom1, denom2;
        
        switch(difficulty) {
            case 'easy':
                whole1 = Math.floor(Math.random() * 5) + 1;
                whole2 = Math.floor(Math.random() * 5) + 1;
                denom1 = Math.floor(Math.random() * 4) + 2;
                denom2 = Math.floor(Math.random() * 4) + 2;
                break;
            case 'medium':
                whole1 = Math.floor(Math.random() * 8) + 1;
                whole2 = Math.floor(Math.random() * 8) + 1;
                denom1 = Math.floor(Math.random() * 6) + 3;
                denom2 = Math.floor(Math.random() * 6) + 3;
                break;
            case 'hard':
                whole1 = Math.floor(Math.random() * 12) + 1;
                whole2 = Math.floor(Math.random() * 12) + 1;
                denom1 = Math.floor(Math.random() * 8) + 4;
                denom2 = Math.floor(Math.random() * 8) + 4;
                break;
        }

        num1 = Math.floor(Math.random() * (denom1 - 1)) + 1;
        num2 = Math.floor(Math.random() * (denom2 - 1)) + 1;

        const problem = `${whole1} ${num1}/${denom1} + ${whole2} ${num2}/${denom2} = `;
        const answer = this.addMixedNumbers(whole1, num1, denom1, whole2, num2, denom2);
        
        return { problem, answer };
    }

    generateDecimals(difficulty, grade) {
        let num1, num2;
        let decimals;
        
        switch(difficulty) {
            case 'easy':
                decimals = 1;
                break;
            case 'medium':
                decimals = 2;
                break;
            case 'hard':
                decimals = 3;
                break;
        }

        num1 = (Math.random() * 10).toFixed(decimals);
        num2 = (Math.random() * 10).toFixed(decimals);

        const operation = Math.random() < 0.5 ? '+' : '-';
        const problem = `${num1} ${operation} ${num2} = `;
        const answer = operation === '+' ? 
            (parseFloat(num1) + parseFloat(num2)).toFixed(decimals) : 
            (parseFloat(num1) - parseFloat(num2)).toFixed(decimals);
        
        return { problem, answer };
    }

    // Helper methods for fraction calculations
    gcd(a, b) {
        return b === 0 ? a : this.gcd(b, a % b);
    }

    addFractions(num1, denom1, num2, denom2) {
        const newDenom = denom1 * denom2;
        const newNum = (num1 * denom2) + (num2 * denom1);
        const gcd = this.gcd(newNum, newDenom);
        return `${newNum/gcd}/${newDenom/gcd}`;
    }

    subtractFractions(num1, denom1, num2, denom2) {
        const newDenom = denom1 * denom2;
        const newNum = (num1 * denom2) - (num2 * denom1);
        const gcd = this.gcd(Math.abs(newNum), newDenom);
        return `${newNum/gcd}/${newDenom/gcd}`;
    }

    addMixedNumbers(whole1, num1, denom1, whole2, num2, denom2) {
        // Convert to improper fractions
        const impNum1 = (whole1 * denom1) + num1;
        const impNum2 = (whole2 * denom2) + num2;
        
        // Add fractions
        const newDenom = denom1 * denom2;
        const newNum = (impNum1 * denom2) + (impNum2 * denom1);
        
        // Convert back to mixed number
        const newWhole = Math.floor(newNum / newDenom);
        const remainderNum = newNum % newDenom;
        const gcd = this.gcd(remainderNum, newDenom);
        
        if (remainderNum === 0) {
            return `${newWhole}`;
        } else {
            return `${newWhole} ${remainderNum/gcd}/${newDenom/gcd}`;
        }
    }

    async downloadPDF() {
        const { jsPDF } = window.jspdf;
        const worksheet = document.querySelector('.worksheet');

        try {
            // Show loading state
            const downloadBtn = document.getElementById('downloadPdf');
            const originalText = downloadBtn.textContent;
            downloadBtn.textContent = 'Generating PDF...';
            downloadBtn.disabled = true;

            // Create PDF
            const pdf = new jsPDF('p', 'mm', 'a4');
            
            // Convert worksheet to canvas
            const canvas = await html2canvas(worksheet, {
                scale: 2,
                useCORS: true,
                logging: false
            });

            // Add image to PDF
            const imgData = canvas.toDataURL('image/jpeg', 1.0);
            const pdfWidth = pdf.internal.pageSize.getWidth();
            const pdfHeight = pdf.internal.pageSize.getHeight();
            const imgWidth = canvas.width;
            const imgHeight = canvas.height;
            const ratio = Math.min(pdfWidth / imgWidth, pdfHeight / imgHeight);
            const imgX = (pdfWidth - imgWidth * ratio) / 2;
            const imgY = 20;

            pdf.addImage(imgData, 'JPEG', imgX, imgY, imgWidth * ratio, imgHeight * ratio);

            // Generate filename
            const date = new Date().toLocaleDateString().replace(/\//g, '-');
            const filename = `worksheet-${date}.pdf`;

            // Download PDF
            pdf.save(filename);

            // Reset button
            downloadBtn.textContent = originalText;
            downloadBtn.disabled = false;

        } catch (error) {
            console.error('PDF generation failed:', error);
            alert('Failed to generate PDF. Please try again.');
            
            // Reset button on error
            const downloadBtn = document.getElementById('downloadPdf');
            downloadBtn.textContent = 'Download PDF';
            downloadBtn.disabled = false;
        }
    }

    printWorksheet() {
        // Store the current body content
        const originalContent = document.body.innerHTML;
        
        // Create a print-only version
        const worksheetContent = document.querySelector('.worksheet').outerHTML;
        document.body.innerHTML = `
            <div class="print-only">
                ${worksheetContent}
            </div>
        `;
        
        // Print
        window.print();
        
        // Restore the original content
        document.body.innerHTML = originalContent;
        
        // Reinitialize the generator
        new WorksheetGenerator();
    }

    displayWorksheet(problems) {
        this.currentProblems = problems;
        const preview = document.querySelector('.worksheet-preview');
        
        // Get all custom options
        const options = this.getCustomOptions();
        
        // Generate worksheet HTML with custom options
        const worksheetHtml = this.generateWorksheetHtml(problems, options);
        
        preview.innerHTML = worksheetHtml;
    }

    getCustomOptions() {
        return {
            title: document.getElementById('customTitle').checked ? 
                   document.getElementById('worksheetTitle').value : 'Math Worksheet',
            showTimer: document.getElementById('showTimer').checked,
            timeLimit: document.getElementById('timeLimit').value,
            fontSize: document.querySelector('select[name="fontSize"]').value,
            layout: document.querySelector('select[name="layout"]').value,
            problemFormat: document.querySelector('input[name="problemFormat"]:checked').id,
            showWorkSpace: document.getElementById('showWorkSpace').checked,
            boxedAnswers: document.getElementById('boxedAnswers').checked,
            guidedSteps: document.getElementById('guidedSteps').checked,
            showStudentName: document.getElementById('studentName').checked,
            showDate: document.getElementById('date').checked,
            showScore: document.getElementById('score').checked,
            numberLine: document.getElementById('numberLine').checked,
            gridPaper: document.getElementById('gridPaper').checked,
            showHints: document.getElementById('hints').checked,
            instructions: document.getElementById('instructions').checked ? 
                         document.getElementById('customInstructions').value : ''
        };
    }

    generateWorksheetHtml(problems, options) {
        let html = `
            <div class="worksheet">
                <div class="worksheet-header">
                    <h2>${options.title}</h2>
                    <div class="student-info">
                        <div class="info-line">Name: _____________________</div>
                        <div class="info-line">Date: _____________________</div>
                    </div>
                </div>
                <div class="problems-grid">
        `;

        // Split problems into pages if needed (20 problems per page)
        const problemsPerPage = 20;
        const pages = Math.ceil(problems.length / problemsPerPage);

        for (let page = 0; page < pages; page++) {
            const startIdx = page * problemsPerPage;
            const endIdx = Math.min((page + 1) * problemsPerPage, problems.length);
            
            if (page > 0) {
                html += `
                    </div>
                    <div class="page-break"></div>
                    <div class="worksheet-header">
                        <h2>Math Practice Worksheet - Page ${page + 1}</h2>
                        <div class="student-info">
                            <div class="info-line">Name: _____________________</div>
                            <div class="info-line">Date: _____________________</div>
                        </div>
                    </div>
                    <div class="problems-grid">
                `;
            }

            for (let i = startIdx; i < endIdx; i++) {
                html += `
                    <div class="problem">
                        <div class="problem-content">
                            <span class="problem-number">${i + 1}.</span>
                            <span class="problem-text">${problems[i].problem}</span>
                            ${options.showWorkSpace ? `<div class="answer-space"></div>` : ''}
                        </div>
                    </div>
                `;
            }
        }

        html += `
                </div>
            </div>
        `;

        return html;
    }
}

// Initialize the generator
new WorksheetGenerator(); 