class WorksheetGenerator {
    constructor() {
        // Wait for DOM to be ready
        document.addEventListener('DOMContentLoaded', () => {
            this.initialize();
        });
    }

    initialize() {
        // Get form elements
        this.form = document.getElementById('worksheetForm');
        this.previewArea = document.querySelector('.worksheet-preview');
        this.generateButton = document.querySelector('.generate-button');
        this.topicSelect = document.getElementById('topic');
        this.numProblems = document.getElementById('numProblems');
        this.fontSize = document.getElementById('fontSize');
        this.showScore = document.getElementById('showScore');
        this.showTime = document.getElementById('showTime');
        this.timeLimit = document.getElementById('timeLimit');

        // Add event listeners
        if (this.form) {
            this.form.addEventListener('submit', (e) => this.handleGenerate(e));
        }

        // Show/hide time limit field based on showTime checkbox
        if (this.showTime) {
            this.showTime.addEventListener('change', () => {
                const timeLimitGroup = document.querySelector('.time-limit-group');
                if (timeLimitGroup) {
                    timeLimitGroup.style.display = this.showTime.checked ? 'block' : 'none';
                }
            });
        }

        // Initialize topic handlers
        this.topicHandlers = {
            'Addition': this.generateAddition.bind(this),
            'Subtraction': this.generateSubtraction.bind(this),
            'Multiplication': this.generateMultiplication.bind(this),
            'Division': this.generateDivision.bind(this)
        };
    }

    handleGenerate(e) {
        e.preventDefault();
        
        const topic = this.topicSelect.value;
        const difficulty = document.querySelector('input[name="difficulty"]:checked')?.value || 'medium';
        let numProblems = this.numProblems.value;

        // Debug log
        console.log('Requested problems:', numProblems);

        // Validate for only positive integers
        if (!Number.isInteger(Number(numProblems)) || numProblems.includes('.') || numProblems.includes('e')) {
            alert('Please enter only whole numbers (no decimals or special characters)');
            this.numProblems.value = Math.floor(Number(numProblems)) || 10;
            return;
        }

        numProblems = parseInt(numProblems);
        console.log('Parsed problems:', numProblems);

        // Validate inputs
        if (!topic || !this.topicHandlers[topic]) {
            alert('Please select a valid topic');
            return;
        }

        if (numProblems < 1) {
            alert('Please enter at least 1 problem');
            return;
        }

        // Generate problems with exact count
        const problems = [];
        for (let i = 0; i < numProblems; i++) {
            problems.push(this.topicHandlers[topic](difficulty));
        }
        
        console.log('Generated problems count:', problems.length);
        
        this.displayWorksheet(problems, topic);
    }

    generateProblems(topic, difficulty, numProblems) {
        const handler = this.topicHandlers[topic];
        if (!handler) return [];

        const problems = [];
        for (let i = 0; i < numProblems; i++) {
            problems.push(handler(difficulty));
        }
        return problems;
    }

    generateAddition(difficulty) {
        let num1, num2;
        switch(difficulty) {
            case 'easy':
                num1 = Math.floor(Math.random() * 10) + 1;
                num2 = Math.floor(Math.random() * 10) + 1;
                break;
            case 'medium':
                num1 = Math.floor(Math.random() * 90) + 10;
                num2 = Math.floor(Math.random() * 90) + 10;
                break;
            case 'hard':
                num1 = Math.floor(Math.random() * 900) + 100;
                num2 = Math.floor(Math.random() * 900) + 100;
                break;
            default:
                num1 = Math.floor(Math.random() * 90) + 10;
                num2 = Math.floor(Math.random() * 90) + 10;
        }
        return {
            question: `${num1} + ${num2} = `,
            answer: num1 + num2
        };
    }

    generateSubtraction(difficulty) {
        let num1, num2;
        switch(difficulty) {
            case 'easy':
                num2 = Math.floor(Math.random() * 10) + 1;
                num1 = num2 + Math.floor(Math.random() * 10) + 1;
                break;
            case 'medium':
                num2 = Math.floor(Math.random() * 90) + 10;
                num1 = num2 + Math.floor(Math.random() * 90) + 10;
                break;
            case 'hard':
                num2 = Math.floor(Math.random() * 900) + 100;
                num1 = num2 + Math.floor(Math.random() * 900) + 100;
                break;
            default:
                num2 = Math.floor(Math.random() * 90) + 10;
                num1 = num2 + Math.floor(Math.random() * 90) + 10;
        }
        return {
            question: `${num1} - ${num2} = `,
            answer: num1 - num2
        };
    }

    generateMultiplication(difficulty) {
        let num1, num2;
        switch(difficulty) {
            case 'easy':
                num1 = Math.floor(Math.random() * 10) + 1;
                num2 = Math.floor(Math.random() * 10) + 1;
                break;
            case 'medium':
                num1 = Math.floor(Math.random() * 12) + 1;
                num2 = Math.floor(Math.random() * 12) + 1;
                break;
            case 'hard':
                num1 = Math.floor(Math.random() * 20) + 1;
                num2 = Math.floor(Math.random() * 20) + 1;
                break;
            default:
                num1 = Math.floor(Math.random() * 12) + 1;
                num2 = Math.floor(Math.random() * 12) + 1;
        }
        return {
            question: `${num1} × ${num2} = `,
            answer: num1 * num2
        };
    }

    generateDivision(difficulty) {
        let num1, num2, product;
        switch(difficulty) {
            case 'easy':
                num2 = Math.floor(Math.random() * 9) + 1;
                num1 = Math.floor(Math.random() * 9) + 1;
                product = num1 * num2;
                break;
            case 'medium':
                num2 = Math.floor(Math.random() * 11) + 2;
                num1 = Math.floor(Math.random() * 11) + 2;
                product = num1 * num2;
                break;
            case 'hard':
                num2 = Math.floor(Math.random() * 19) + 2;
                num1 = Math.floor(Math.random() * 19) + 2;
                product = num1 * num2;
                break;
            default:
                num2 = Math.floor(Math.random() * 11) + 2;
                num1 = Math.floor(Math.random() * 11) + 2;
                product = num1 * num2;
        }
        return {
            question: `${product} ÷ ${num2} = `,
            answer: num1
        };
    }

    displayWorksheet(problems, topic) {
        if (!this.previewArea) return;
        console.log('Display problems count:', problems.length);

        const worksheetContainer = document.createElement('div');
        worksheetContainer.className = 'worksheet-container';

        // Split problems into pages (16 problems per page)
        const problemsPerPage = 16;
        const pages = Math.ceil(problems.length / problemsPerPage);

        // Create practice worksheet pages
        for (let i = 0; i < pages; i++) {
            const startIndex = i * problemsPerPage;
            const endIndex = startIndex + problemsPerPage;
            const pageProblems = problems.slice(startIndex, endIndex);
            console.log(`Page ${i + 1} problems:`, pageProblems.length);
            
            const practiceWorksheet = this.createWorksheetPage(pageProblems, topic, i + 1, pages);
            worksheetContainer.appendChild(practiceWorksheet);
        }

        // Create answer key with all problems
        const answerKey = this.createAnswerKeyPage(problems, topic);
        worksheetContainer.appendChild(answerKey);

        this.previewArea.innerHTML = '';
        this.addActionButtons();
        this.previewArea.appendChild(worksheetContainer);
    }

    createWorksheetPage(problems, topic, pageNum, totalPages) {
        const page = document.createElement('div');
        page.className = 'worksheet';
        
        // Apply font size
        if (this.fontSize) {
            page.style.fontSize = this.fontSize.value + 'px';
        }

        // Add worksheet header
        const header = document.createElement('div');
        header.className = 'worksheet-header';
        
        let headerContent = `
            <h2>${topic} Practice Worksheet ${totalPages > 1 ? `(Page ${pageNum} of ${totalPages})` : ''}</h2>
            <div class="worksheet-info">
                <div>Name: _________________</div>
                <div>Date: _________________</div>
            </div>
        `;

        // Add score field if selected
        if (this.showScore && this.showScore.checked) {
            headerContent += `
                <div class="score-field">
                    Score: ______ / ${problems.length}
                </div>
            `;
        }

        // Add time field if selected
        if (this.showTime && this.showTime.checked) {
            const timeLimit = this.timeLimit ? this.timeLimit.value : '';
            headerContent += `
                <div class="time-field">
                    Time${timeLimit ? ` (${timeLimit} minutes)` : ''}: Start _______ End _______
                </div>
            `;
        }

        header.innerHTML = headerContent;
        page.appendChild(header);

        // Add problems
        const problemsGrid = document.createElement('div');
        problemsGrid.className = 'problems-grid';

        problems.forEach((problem, index) => {
            const problemDiv = document.createElement('div');
            problemDiv.className = 'problem';
            problemDiv.innerHTML = `
                <div class="problem-content">
                    <span class="problem-number">${(pageNum - 1) * 16 + index + 1}.</span>
                    <span class="problem-text">${problem.question}</span>
                    <div class="answer-space"></div>
                </div>
            `;
            problemsGrid.appendChild(problemDiv);
        });

        page.appendChild(problemsGrid);
        return page;
    }

    createAnswerKeyPage(problems, topic) {
        const page = document.createElement('div');
        page.className = 'worksheet answer-key-page';

        // Add answer key header
        const header = document.createElement('div');
        header.className = 'worksheet-header';
        header.innerHTML = `
            <h2>${topic} Practice Worksheet - Answer Key</h2>
            <div class="worksheet-info">
                <div>Date: _________________</div>
            </div>
        `;
        page.appendChild(header);

        // Add answers only
        const answersGrid = document.createElement('div');
        answersGrid.className = 'answers-grid';

        problems.forEach((problem, index) => {
            const answerDiv = document.createElement('div');
            answerDiv.className = 'answer-item';
            answerDiv.innerHTML = `
                <span class="problem-number">${index + 1}.</span>
                <span class="answer-text">${problem.answer}</span>
            `;
            answersGrid.appendChild(answerDiv);
        });

        page.appendChild(answersGrid);
        return page;
    }

    // Add print function
    printWorksheet() {
        window.print();
    }

    // Add download function
    downloadWorksheet() {
        const worksheetContent = this.previewArea.innerHTML;
        const style = `
            <style>
                /* Add all necessary styles for the worksheet here */
                .worksheet {
                    padding: 40px;
                    margin-bottom: 30px;
                }
                .worksheet-header {
                    margin-bottom: 30px;
                }
                .problems-grid {
                    display: grid;
                    grid-template-columns: repeat(2, 1fr);
                    gap: 20px;
                }
                .problem {
                    margin-bottom: 15px;
                }
                .answer-space {
                    min-height: 40px;
                    border-bottom: 1px solid #ccc;
                }
                @media print {
                    .worksheet {
                        page-break-after: always;
                    }
                    .answer-key-page {
                        page-break-before: always;
                    }
                }
            </style>
        `;

        // Create the full HTML document
        const html = `
            <!DOCTYPE html>
            <html>
            <head>
                <title>Math Worksheet</title>
                ${style}
            </head>
            <body>
                ${worksheetContent}
            </body>
            </html>
        `;

        // Create blob and download
        const blob = new Blob([html], { type: 'text/html' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'math-worksheet.html';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
    }

    // Add buttons to the worksheet preview
    addActionButtons() {
        const buttonContainer = document.createElement('div');
        buttonContainer.className = 'worksheet-actions';
        
        const printButton = document.createElement('button');
        printButton.className = 'action-button print-button';
        printButton.innerHTML = '<i class="fas fa-print"></i> Print Worksheet';
        printButton.onclick = () => this.printWorksheet();

        const downloadButton = document.createElement('button');
        downloadButton.className = 'action-button download-button';
        downloadButton.innerHTML = '<i class="fas fa-download"></i> Download Worksheet';
        downloadButton.onclick = () => this.downloadWorksheet();

        buttonContainer.appendChild(printButton);
        buttonContainer.appendChild(downloadButton);
        
        // Add buttons before the worksheet preview
        this.previewArea.insertBefore(buttonContainer, this.previewArea.firstChild);
    }
}

// Initialize the generator
new WorksheetGenerator(); 