// Scroll Header
window.addEventListener('scroll', () => {
    const header = document.querySelector('header');
    if (window.scrollY > 100) {
        header.classList.add('scrolled');
    } else {
        header.classList.remove('scrolled');
    }
});

// Scroll Reveal
const reveals = document.querySelectorAll('.reveal');

const revealOnScroll = () => {
    reveals.forEach(element => {
        const windowHeight = window.innerHeight;
        const elementTop = element.getBoundingClientRect().top;
        const elementVisible = 150;

        if (elementTop < windowHeight - elementVisible) {
            element.classList.add('active');
        }
    });
};

window.addEventListener('scroll', revealOnScroll);

document.addEventListener('DOMContentLoaded', () => {
    const toggleBtns = document.querySelectorAll('.toggle-btn');
    const toggleWrapper = document.querySelector('.pricing-toggle');
    
    function updatePrices(plan) {
        document.body.dataset.pricing = plan;
        toggleWrapper.dataset.active = plan;
        
        document.querySelectorAll('.price-card').forEach(card => {
            const priceAmount = card.querySelector('.price-amount');
            const yearlyPrice = card.querySelector('.yearly-price');
            
            if (plan === 'yearly' && yearlyPrice) {
                // Extract the yearly price and multiply by 12
                const price = parseInt(yearlyPrice.textContent.replace(/[^0-9]/g, ''));
                priceAmount.textContent = price * 12;
            } else {
                const monthlyPrice = card.querySelector('.monthly-price');
                priceAmount.textContent = parseInt(monthlyPrice.textContent.replace(/[^0-9]/g, ''));
            }
            
            priceAmount.classList.add('changing');
            setTimeout(() => {
                priceAmount.classList.remove('changing');
            }, 400);
        });
    }

    toggleBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            if (!btn.classList.contains('active')) {
                toggleBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                updatePrices(btn.dataset.plan);
            }
        });
    });

    // Add click handlers for CTA buttons
    const ctaButtons = document.querySelectorAll('.cta-button');
    ctaButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            e.preventDefault();
            window.location.href = 'generator.html';  // Updated to generator.html
        });
    });
});

document.addEventListener('DOMContentLoaded', function() {
    const sidebar = document.querySelector('.sidebar');
    const mainContent = document.querySelector('main') || document.querySelector('.generator-main');
    const toggleButton = document.querySelector('.sidebar-toggle');

    if (toggleButton && sidebar && mainContent) {
        // Set initial state from localStorage
        const sidebarCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
        if (sidebarCollapsed) {
            sidebar.classList.add('collapsed');
            mainContent.classList.add('sidebar-collapsed');
        }

        // Toggle function
        toggleButton.addEventListener('click', () => {
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('sidebar-collapsed');
            
            // Save state to localStorage
            localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed'));
        });
    }
});

// Navigation functionality
document.addEventListener('DOMContentLoaded', () => {
    // Get current page path
    const currentPath = window.location.pathname;
    
    // Get all nav links
    const navLinks = document.querySelectorAll('.nav-link');
    
    // Get mobile menu toggle
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const mainNav = document.querySelector('.main-nav');
    
    // Handle mobile menu toggle
    if (mobileMenuToggle) {
        mobileMenuToggle.addEventListener('click', () => {
            mainNav.classList.toggle('active');
        });
    }
    
    // Handle active states
    navLinks.forEach(link => {
        link.classList.remove('active');
        
        // Get the href path
        const linkPath = link.getAttribute('href');
        
        // Check if current path matches link path
        if (currentPath === linkPath || 
            (currentPath.includes(linkPath) && linkPath !== '/')) {
            link.classList.add('active');
        }
        
        // Close mobile menu when link is clicked
        link.addEventListener('click', () => {
            if (window.innerWidth <= 768) {
                mainNav.classList.remove('active');
            }
        });
    });
});
